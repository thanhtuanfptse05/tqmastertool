# TẬP QUY TẮC VIẾT CODE – MÔN LAB211

## 0. Quy định bắt buộc (Mandatory)

- **Ngôn ngữ lập trình:** Toàn bộ các bài tập OOP đều **bắt buộc phải code bằng Java**.
- **Môi trường & Công cụ chuẩn:**
  - **Loại dự án:** Bắt buộc tạo theo kiểu **Java with Ant** (Java Application sử dụng Apache Ant, không dùng Maven/Gradle).
  - **IDE:** Tương thích chuẩn với **Apache NetBeans 17**.
  - **Phiên bản Java:** Chuẩn chỉnh **JDK 8 (Java SE 8 / 1.8)**. Code phải tương thích và chạy ổn định trên JDK 8 của môi trường chấm/máy thi.
- **Mô hình kiến trúc:**
  - Đối với các bài toán quản lý, bài toán nghiệp vụ tương tác phức tạp (Shape, BMI, Worker, User Management, EBank, Task Management, Matrix, Fruit...): **Bắt buộc phải thiết kế và viết theo chuẩn mô hình MVC (Model - View - Controller)**.
    - **Model:** Định nghĩa các đối tượng/thực thể dữ liệu (Entity/POJO như `Student`, `Product`...). Chỉ quản lý dữ liệu, trạng thái, constructor, getter/setter; **tuyệt đối không chứa** code giao tiếp người dùng (`Scanner`, `System.out.println`).
    - **View:** Đảm nhiệm hiển thị giao diện (Console), in menu, hiển thị kết quả, thông báo lỗi. Khi cần nhận và kiểm tra dữ liệu nhập, View sẽ gọi thông qua Controller.
    - **Controller:** Đóng vai trò cầu nối điều phối giữa View và Model; tiếp nhận sự kiện/yêu cầu từ View, thực hiện xử lý logic nghiệp vụ (thêm, sửa, xóa, tìm kiếm, sắp xếp, tính toán...) và cập nhật hoặc trả dữ liệu cho View hiển thị. **ĐẶC BIỆT BẮT BUỘC:** Toàn bộ logic kiểm tra, xác thực tính hợp lệ của dữ liệu đầu vào (Validation / `InputValidator` / `Validation`) **phải nằm ở tầng Controller (trong package `controller`)**.
  - Đối với các bài thuật toán nền tảng đơn giản (như `P0006 - BinarySearch`, `P0009 - Fibonacci`, `P0010 - Linear Search`): **Không cần áp dụng cấu trúc MVC**, chỉ cần tuân thủ **chuẩn OOP** (Object-Oriented Programming), phân tách rành mạch các class chức năng (thuật toán / dữ liệu, validation, main điều khiển) thành các file class riêng biệt, **tuyệt đối không viết chung vào 1 class hay dồn hết vào `main()`**.

## 1. Quy tắc đặt tên (Naming Convention)

- **Class name:** Viết theo kiểu `PascalCase` (mỗi từ viết hoa chữ cái đầu).
  - Ví dụ: `StudentManager`, `Product`, `LibrarySystem`
- **Method name:** Viết theo kiểu `camelCase`.
  - Ví dụ: `calculateGPA()`, `findById()`
- **Variable name:** Viết theo kiểu `camelCase`.
  - Ví dụ: `studentList`, `totalPrice`
- **Hằng số (constant):** Viết in hoa, các từ phân tách bằng dấu gạch dưới `_`.
  - Ví dụ: `MAX_SCORE`

## 2. Cấu trúc chương trình theo mô hình MVC

- Phân chia package và class rõ ràng tương ứng với các thành phần của MVC:
  - `model`: chứa các class thực thể (ví dụ: `Student.java`).
  - `view`: chứa các class hiển thị màn hình, menu, tương tác console với người dùng (ví dụ: `StudentView.java`, `Menu.java`).
  - `controller`: chứa các class điều khiển, xử lý nghiệp vụ quản lý dữ liệu (ví dụ: `StudentController.java`) **VÀ các class/phương thức validation dữ liệu đầu vào (ví dụ: `InputValidator.java`, `Validation.java`)**.
- Mỗi class đảm nhiệm một vai trò duy nhất (**Single Responsibility**):
  - `Student.java`: chỉ định nghĩa đối tượng Sinh viên (Model).
  - `StudentController.java`: xử lý các thao tác quản lý danh sách và nghiệp vụ (Controller).
  - `InputValidator.java`: xử lý kiểm tra và nhập dữ liệu hợp lệ (nằm trong Controller).
  - `StudentView.java` / `Main.java`: chứa menu điều khiển, gọi validator/controller và hiển thị kết quả (View/Main).
- Không để logic xử lý lẫn lộn giữa các tầng/lớp:
  - Ví dụ: không để code `Scanner` nhập dữ liệu hoặc in giao diện trực tiếp trong `Student` (Model).

## 3. Quy tắc về Method

- Mỗi phương thức chỉ nên xử lý một nhiệm vụ cụ thể (**Single Responsibility**).
- Tên phương thức phải thể hiện rõ chức năng.
  - Ví dụ: `calculateAge()` tốt hơn `process1()`.
- Đối với các hành động, đặt tên rõ ràng và nhất quán:
  - `get`: lấy thông tin.
  - `set`: gán giá trị.
  - `add`: thêm.
  - `remove`: xóa.
  - `find`: tìm kiếm.
  - `sort`: sắp xếp.
  - `print`: in thông tin.
  - `input`: nhập dữ liệu.
  - `update`: cập nhật.

## 4. Validation dữ liệu đầu vào

- **Vị trí bắt buộc:** Toàn bộ các class hoặc phương thức kiểm tra/xác thực dữ liệu đầu vào (như `InputValidator.java`, `Validation.java`) **BẮT BUỘC PHẢI NẰM TRONG PACKAGE `controller`** (tuyệt đối không để trong package `view` hay `model`).
- Tầng `view` khi cần nhận và kiểm tra dữ liệu từ người dùng sẽ gọi thông qua các hàm validate thuộc package `controller`.
- Bắt buộc kiểm tra và xử lý ngoại lệ (**exception**) cho tất cả các đầu vào từ người dùng:
  - Dữ liệu rỗng.
  - Sai kiểu dữ liệu.
  - Vượt giới hạn.
  - Sai định dạng.
  - Các trường hợp nhập dữ liệu không hợp lệ khác.
- Có thể sử dụng các phương thức hỗ trợ như:

```java
public static int inputInteger(String msg, int min, int max);

public static String inputString(String msg, String regex);
```

## 5. Encapsulation

- Tất cả thuộc tính (**attribute**) trong class phải là `private`.
- Cung cấp `getter` và `setter` nếu cần thiết.
- Không để biến `public` nếu không có lý do rõ ràng.

## 6. Tuân thủ nguyên tắc OOP

- Áp dụng đúng các đặc tính của lập trình hướng đối tượng:
  - **Encapsulation** – Đóng gói.
  - **Abstraction** – Trừu tượng.
  - **Inheritance** – Kế thừa.
  - **Polymorphism** – Đa hình.
- Không viết toàn bộ chương trình trong `main()` hoặc trong một class duy nhất.
- Có thể có một số ngoại lệ rõ ràng tùy theo yêu cầu bài tập.

## 7. Định dạng và bố cục

- Dùng **indent = 4 spaces**, không dùng `Tab`.
- Mỗi file Java nên có comment tên lớp và mô tả ngắn gọn chức năng.
- Có khoảng trắng hợp lý giữa các phương thức và các khối lệnh.
- Tránh viết quá dài trong một phương thức.
  - Phương thức dài hơn **30 dòng** là dấu hiệu nên xem xét tách nhỏ thành các phương thức khác.

## 8. Comment & Documentation

- Comment đúng mức, không lạm dụng.
- Ưu tiên viết code rõ ràng, dễ đọc thay vì giải thích quá nhiều bằng comment.
- Các method nên có mô tả đầu dòng theo chuẩn **Javadoc**.

Ví dụ:

```java
/**
 * Tính tổng tiền cho một sản phẩm.
 *
 * @return tổng tiền
 */
```

## 9. Những điều không được phép (DON'T)

- Không dùng `break` và `continue` bừa bãi trong vòng lặp.
- Không để code lặp lại logic giống nhau ở nhiều nơi.
  - Tuân thủ nguyên tắc **DRY (Don't Repeat Yourself)**.
- Không viết class chứa toàn biến `static` nếu không cần thiết.
- Không chép code từ nguồn ngoài nếu không hiểu rõ cách hoạt động của code.
- Không sử dụng các cú pháp và tính năng từ Java 9 trở lên (ví dụ: từ khóa `var`, `List.of()`, `Map.of()`, `record`, switch expression `->`, `Stream.toList()`...) gây lỗi khi biên dịch với **JDK 8**.

## 10. Kiểm tra chương trình

- Kiểm tra tất cả các chức năng được yêu cầu hoạt động đúng.
- Kiểm tra các trường hợp biên:
  - Dữ liệu trống.
  - Sai định dạng.
  - Nhập lại dữ liệu.
  - Dữ liệu vượt giới hạn.
  - Các trường hợp bất thường khác.
- Đảm bảo chương trình không bị crash khi người dùng nhập sai.
- Đảm bảo các thông báo lỗi thân thiện và dễ hiểu với người dùng.
- Đảm bảo hiểu hết **control flow** và **data flow** trong chương trình.
- Đảm bảo hiểu và có thể giải thích được cách thức hoạt động của từng dòng lệnh trong chương trình.
