import candidatemanagement.controller.CandidateController;
import candidatemanagement.model.Candidate;
import candidatemanagement.model.ExperienceCandidate;
import candidatemanagement.model.FresherCandidate;
import candidatemanagement.model.InternCandidate;
import org.junit.Before;
import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

/**
 * JUnit tests for CandidateController (J1.L.P0022).
 */
public class CandidateControllerTest {

    private CandidateController controller;

    @Before
    public void setUp() {
        controller = new CandidateController();
    }

    @Test
    public void testCreateExperience_and_count() {
        controller.createExperienceCandidate("E001", "John", "Doe", 1990,
                "HCM", "0901234567", "john@test.com", 5, "Java");
        assertEquals(1, controller.getCandidateCount());
    }

    @Test
    public void testCreateFresher_and_count() {
        controller.createFresherCandidate("F001", "Jane", "Smith", 2001,
                "HN", "0901234568", "jane@test.com", "2023-06", "Good", "FPT Univ");
        assertEquals(1, controller.getCandidateCount());
    }

    @Test
    public void testCreateIntern_and_count() {
        controller.createInternCandidate("I001", "Alice", "Tran", 2004,
                "DN", "0901234569", "alice@test.com", "IT", 5, "HUST");
        assertEquals(1, controller.getCandidateCount());
    }

    @Test
    public void testIsIdDuplicate_true() {
        controller.createExperienceCandidate("E001", "John", "Doe", 1990,
                "HCM", "0901234567", "john@test.com", 5, "Java");
        assertTrue(controller.isIdDuplicate("E001"));
    }

    @Test
    public void testIsIdDuplicate_false() {
        assertFalse(controller.isIdDuplicate("NOTEXIST"));
    }

    @Test
    public void testGetCandidatesByType_experience() {
        controller.createExperienceCandidate("E001", "John", "Doe", 1990,
                "HCM", "0901234567", "john@test.com", 5, "Java");
        controller.createFresherCandidate("F001", "Jane", "Smith", 2001,
                "HN", "0901234568", "jane@test.com", "2023-06", "Good", "FPT");
        List<Candidate> exp = controller.getCandidatesByType(Candidate.TYPE_EXPERIENCE);
        assertEquals(1, exp.size());
        assertEquals("E001", exp.get(0).getCandidateId());
    }

    @Test
    public void testSearchByNameAndType_found_firstName() {
        controller.createExperienceCandidate("E001", "Eva", "Aguirre", 1990,
                "HCM", "0940394123", "eva@asante.com", 3, "Java");
        controller.createExperienceCandidate("E002", "Adeleva", "Antosova", 1989,
                "DN", "0984933456", "adeleva@janeo.com", 2, ".Net");
        List<Candidate> result = controller.searchByNameAndType("eva", 0);
        assertEquals(2, result.size()); // Eva (firstName) + Adeleva (contains "eva")
    }

    @Test
    public void testSearchByNameAndType_found_lastName() {
        controller.createFresherCandidate("F001", "John", "Nguyen", 2001,
                "HN", "0901234568", "john@fpt.com", "2023-06", "Good", "FPT");
        List<Candidate> result = controller.searchByNameAndType("nguyen", 1);
        assertEquals(1, result.size());
    }

    @Test
    public void testSearchByNameAndType_wrongType_returnsEmpty() {
        controller.createExperienceCandidate("E001", "Eva", "Test", 1990,
                "HCM", "0901234567", "eva@test.com", 3, "Java");
        // Search type 1 (Fresher) but candidate is type 0 (Experience)
        List<Candidate> result = controller.searchByNameAndType("eva", 1);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testCandidateTypeLabels() {
        ExperienceCandidate ec = new ExperienceCandidate("E001","A","B",1990,"HCM","0901234567","a@b.com",3,"Java");
        FresherCandidate fc   = new FresherCandidate("F001","C","D",2000,"HN","0901234568","c@d.com","2023","Good","FPT");
        InternCandidate ic    = new InternCandidate("I001","E","F",2004,"DN","0901234569","e@f.com","IT",5,"HUST");
        assertEquals("Experience", ec.getCandidateTypeLabel());
        assertEquals("Fresher",    fc.getCandidateTypeLabel());
        assertEquals("Intern",     ic.getCandidateTypeLabel());
    }

    @Test
    public void testFullName() {
        ExperienceCandidate ec = new ExperienceCandidate("E001","John","Doe",1990,"HCM","0901234567","j@d.com",5,"Java");
        assertEquals("John Doe", ec.getFullName());
    }
}
