import studentmanagement.controller.StudentController;
import studentmanagement.model.Student;
import org.junit.Before;
import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

/**
 * JUnit tests for StudentController (J1.L.P0021).
 */
public class StudentControllerTest {

    private StudentController controller;

    @Before
    public void setUp() {
        controller = new StudentController();
    }

    @Test
    public void testAddAndCount() {
        controller.addStudent(new Student("S001", "Nguyen Van A", 1, "Java"));
        assertEquals(1, controller.getStudentCount());
    }

    @Test
    public void testIsIdDuplicate_false() {
        assertFalse(controller.isIdDuplicate("S001"));
    }

    @Test
    public void testIsIdDuplicate_true() {
        controller.addStudent(new Student("S001", "Nguyen Van A", 1, "Java"));
        assertTrue(controller.isIdDuplicate("S001"));
    }

    @Test
    public void testIsIdDuplicate_caseInsensitive() {
        controller.addStudent(new Student("S001", "Nguyen Van A", 1, "Java"));
        assertTrue(controller.isIdDuplicate("s001"));
    }

    @Test
    public void testFindById_found() {
        controller.addStudent(new Student("S002", "Tran Van B", 2, ".Net"));
        Student s = controller.findById("S002");
        assertNotNull(s);
        assertEquals("Tran Van B", s.getStudentName());
    }

    @Test
    public void testFindById_notFound() {
        assertNull(controller.findById("NOTEXIST"));
    }

    @Test
    public void testFindAndSortByName_partialMatch() {
        controller.addStudent(new Student("S001", "Nguyen Van A", 1, "Java"));
        controller.addStudent(new Student("S002", "Nguyen Van B", 1, ".Net"));
        controller.addStudent(new Student("S003", "Tran Van C",   2, "C/C++"));
        List<Student> result = controller.findAndSortByName("nguyen");
        assertEquals(2, result.size());
    }

    @Test
    public void testFindAndSortByName_sorted() {
        controller.addStudent(new Student("S001", "Zurich Alpha", 1, "Java"));
        controller.addStudent(new Student("S002", "Apple Beta",   2, ".Net"));
        List<Student> result = controller.findAndSortByName("");
        assertEquals("Apple Beta", result.get(0).getStudentName());
    }

    @Test
    public void testFindAndSortByName_noMatch() {
        controller.addStudent(new Student("S001", "Nguyen Van A", 1, "Java"));
        List<Student> result = controller.findAndSortByName("xyz");
        assertTrue(result.isEmpty());
    }

    @Test
    public void testUpdateStudent_success() {
        controller.addStudent(new Student("S001", "Nguyen Van A", 1, "Java"));
        boolean ok = controller.updateStudent("S001", "Nguyen Van A Updated", 3, ".Net");
        assertTrue(ok);
        assertEquals("Nguyen Van A Updated", controller.findById("S001").getStudentName());
        assertEquals(3, controller.findById("S001").getSemester());
    }

    @Test
    public void testUpdateStudent_notFound() {
        assertFalse(controller.updateStudent("NOTEXIST", "Name", 1, "Java"));
    }

    @Test
    public void testDeleteStudent_success() {
        controller.addStudent(new Student("S001", "Nguyen Van A", 1, "Java"));
        assertTrue(controller.deleteStudent("S001"));
        assertEquals(0, controller.getStudentCount());
    }

    @Test
    public void testDeleteStudent_notFound() {
        assertFalse(controller.deleteStudent("NOTEXIST"));
    }

    @Test
    public void testGenerateReport_counts() {
        controller.addStudent(new Student("S001", "Nguyen Van A", 1, "Java"));
        controller.addStudent(new Student("S002", "Nguyen Van A", 2, "Java"));
        controller.addStudent(new Student("S003", "Nguyen Van A", 3, ".Net"));
        List<String[]> report = controller.generateReport();
        // Should have 2 unique name+course combos: (Nguyen Van A | Java | 2), (Nguyen Van A | .Net | 1)
        assertEquals(2, report.size());
        // Find Java entry
        boolean found = false;
        for (String[] row : report) {
            if (row[1].equals("Java")) {
                assertEquals("2", row[2]);
                found = true;
            }
        }
        assertTrue(found);
    }
}
