import worker.controller.WorkerController;
import worker.model.SalaryStatus;
import worker.model.Worker;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * JUnit tests for WorkerController (J1.S.P0056).
 */
public class WorkerControllerTest {

    private WorkerController controller;

    @Before
    public void setUp() {
        controller = new WorkerController();
    }

    @Test
    public void testAddWorker_success() throws Exception {
        Worker w = new Worker("W001", "Nguyen Van A", 30, 5000000.0, "HCM");
        assertTrue(controller.addWorker(w));
        assertNotNull(controller.findWorkerByCode("W001"));
    }

    @Test(expected = Exception.class)
    public void testAddWorker_duplicateId() throws Exception {
        Worker w1 = new Worker("W001", "Nguyen Van A", 30, 5000000.0, "HCM");
        Worker w2 = new Worker("W001", "Tran Van B", 25, 4000000.0, "HN");
        controller.addWorker(w1);
        controller.addWorker(w2); // should throw
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddWorker_null() throws Exception {
        controller.addWorker(null);
    }

    @Test
    public void testFindWorkerByCode_found() throws Exception {
        Worker w = new Worker("W002", "Le Van C", 28, 3000000.0, "DN");
        controller.addWorker(w);
        Worker found = controller.findWorkerByCode("W002");
        assertNotNull(found);
        assertEquals("Le Van C", found.getName());
    }

    @Test
    public void testFindWorkerByCode_notFound() {
        assertNull(controller.findWorkerByCode("NOTEXIST"));
    }

    @Test
    public void testFindWorkerByCode_caseInsensitive() throws Exception {
        Worker w = new Worker("w003", "Pham D", 22, 2000000.0, "HCM");
        controller.addWorker(w);
        assertNotNull(controller.findWorkerByCode("W003"));
    }

    @Test
    public void testChangeSalary_up() throws Exception {
        Worker w = new Worker("W004", "Nguyen E", 35, 5000000.0, "HN");
        controller.addWorker(w);
        controller.changeSalary(SalaryStatus.UP, "W004", 1000000.0);
        assertEquals(6000000.0, controller.findWorkerByCode("W004").getSalary(), 0.001);
    }

    @Test
    public void testChangeSalary_down() throws Exception {
        Worker w = new Worker("W005", "Tran F", 40, 8000000.0, "HCM");
        controller.addWorker(w);
        controller.changeSalary(SalaryStatus.DOWN, "W005", 2000000.0);
        assertEquals(6000000.0, controller.findWorkerByCode("W005").getSalary(), 0.001);
    }

    @Test(expected = Exception.class)
    public void testChangeSalary_workerNotFound() throws Exception {
        controller.changeSalary(SalaryStatus.UP, "NOTEXIST", 1000.0);
    }

    @Test(expected = Exception.class)
    public void testChangeSalary_zeroAmount() throws Exception {
        Worker w = new Worker("W006", "G", 30, 5000000.0, "HN");
        controller.addWorker(w);
        controller.changeSalary(SalaryStatus.UP, "W006", 0);
    }

    @Test(expected = Exception.class)
    public void testChangeSalary_down_exceedsSalary() throws Exception {
        Worker w = new Worker("W007", "H", 30, 3000000.0, "HN");
        controller.addWorker(w);
        controller.changeSalary(SalaryStatus.DOWN, "W007", 3000000.0); // equal -> should throw
    }

    @Test
    public void testSalaryHistory_recordedAfterChange() throws Exception {
        Worker w = new Worker("W008", "I", 30, 5000000.0, "HCM");
        controller.addWorker(w);
        controller.changeSalary(SalaryStatus.UP, "W008", 500000.0);
        assertEquals(1, controller.getInfomationSalary().size());
    }
}
