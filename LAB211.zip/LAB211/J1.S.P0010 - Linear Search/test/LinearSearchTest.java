import linearsearch.LinearSearch;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * JUnit tests for LinearSearch class (J1.S.P0010).
 */
public class LinearSearchTest {

    private LinearSearch ls;

    @Before
    public void setUp() {
        ls = new LinearSearch(5);
    }

    @Test
    public void testLinearSearch_found_first() {
        ls.setArray(new int[]{10, 20, 30, 40});
        assertEquals(0, ls.linearSearch(new int[]{10, 20, 30, 40}, 10));
    }

    @Test
    public void testLinearSearch_found_last() {
        int[] arr = {10, 20, 30, 40};
        assertEquals(3, ls.linearSearch(arr, 40));
    }

    @Test
    public void testLinearSearch_found_middle() {
        int[] arr = {10, 20, 30, 40};
        assertEquals(1, ls.linearSearch(arr, 20));
    }

    @Test
    public void testLinearSearch_notFound() {
        int[] arr = {10, 20, 30, 40};
        assertEquals(-1, ls.linearSearch(arr, 99));
    }

    @Test
    public void testLinearSearch_emptyArray() {
        ls.setArray(new int[]{});
        assertEquals(-1, ls.search(5));
    }

    @Test
    public void testLinearSearch_singleElement_found() {
        ls.setArray(new int[]{7});
        assertEquals(0, ls.search(7));
    }

    @Test
    public void testLinearSearch_singleElement_notFound() {
        ls.setArray(new int[]{7});
        assertEquals(-1, ls.search(99));
    }

    @Test
    public void testLinearSearch_duplicates_returnsFirst() {
        int[] arr = {5, 5, 5, 5};
        assertEquals(0, ls.linearSearch(arr, 5));
    }
}
