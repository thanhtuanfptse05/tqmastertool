import fibonacci.Fibonacci;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * JUnit tests for Fibonacci class (J1.S.P0009).
 */
public class FibonacciTest {

    @Test
    public void testFibonacci_F0() {
        Fibonacci fib = new Fibonacci(5);
        int[] memo = new int[5];
        assertEquals(0, fib.findFibonacci(0, memo));
    }

    @Test
    public void testFibonacci_F1() {
        Fibonacci fib = new Fibonacci(5);
        int[] memo = new int[5];
        assertEquals(1, fib.findFibonacci(1, memo));
    }

    @Test
    public void testFibonacci_F5() {
        Fibonacci fib = new Fibonacci(10);
        int[] memo = new int[10];
        // F(5) = 5
        assertEquals(5, fib.findFibonacci(5, memo));
    }

    @Test
    public void testFibonacci_F10() {
        Fibonacci fib = new Fibonacci(15);
        int[] memo = new int[15];
        // F(10) = 55
        assertEquals(55, fib.findFibonacci(10, memo));
    }

    @Test
    public void testSequenceString_first5() {
        Fibonacci fib = new Fibonacci(5);
        assertEquals("0, 1, 1, 2, 3", fib.getSequenceString());
    }

    @Test
    public void testSequenceString_zero_terms() {
        Fibonacci fib = new Fibonacci(0);
        assertEquals("", fib.getSequenceString());
    }

    @Test
    public void testSequenceString_negative_terms() {
        Fibonacci fib = new Fibonacci(-1);
        assertEquals("", fib.getSequenceString());
    }

    @Test
    public void testSequenceString_one_term() {
        Fibonacci fib = new Fibonacci(1);
        assertEquals("0", fib.getSequenceString());
    }

    @Test
    public void testMemoization_reuse() {
        Fibonacci fib = new Fibonacci(10);
        int[] memo = new int[10];
        // call twice – should return same result
        int first  = fib.findFibonacci(8, memo);
        int second = fib.findFibonacci(8, memo);
        assertEquals(first, second);
        assertEquals(21, first);
    }
}
