import task.controller.TaskController;
import task.model.Task;
import org.junit.Before;
import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

/**
 * JUnit tests for TaskController (J1.S.P0071).
 */
public class TaskControllerTest {

    private TaskController controller;

    @Before
    public void setUp() {
        controller = new TaskController();
    }

    @Test
    public void testAddTask_success() throws Exception {
        int id = controller.addTask("Req1", "John", "Mary", "1", "01-01-2025", "8.0", "9.0");
        assertEquals(1, id);
        assertEquals(1, controller.getDataTasks().size());
    }

    @Test
    public void testAddTask_idAutoIncrement() throws Exception {
        controller.addTask("Req1", "John", "Mary", "1", "01-01-2025", "8.0", "9.0");
        int id2 = controller.addTask("Req2", "Anna", "Bob", "2", "02-01-2025", "9.0", "10.0");
        assertEquals(2, id2);
    }

    @Test(expected = Exception.class)
    public void testAddTask_emptyRequirement() throws Exception {
        controller.addTask("", "John", "Mary", "1", "01-01-2025", "8.0", "9.0");
    }

    @Test(expected = Exception.class)
    public void testAddTask_emptyAssignee() throws Exception {
        controller.addTask("Req", "", "Mary", "1", "01-01-2025", "8.0", "9.0");
    }

    @Test(expected = Exception.class)
    public void testAddTask_invalidTaskType() throws Exception {
        controller.addTask("Req", "John", "Mary", "5", "01-01-2025", "8.0", "9.0");
    }

    @Test(expected = Exception.class)
    public void testAddTask_invalidDate() throws Exception {
        controller.addTask("Req", "John", "Mary", "1", "32-13-2025", "8.0", "9.0");
    }

    @Test(expected = Exception.class)
    public void testAddTask_planFrom_beforeMin() throws Exception {
        controller.addTask("Req", "John", "Mary", "1", "01-01-2025", "7.0", "9.0");
    }

    @Test(expected = Exception.class)
    public void testAddTask_planTo_exceedsMax() throws Exception {
        controller.addTask("Req", "John", "Mary", "1", "01-01-2025", "8.0", "18.0");
    }

    @Test(expected = Exception.class)
    public void testAddTask_planTo_lessThanFrom() throws Exception {
        controller.addTask("Req", "John", "Mary", "1", "01-01-2025", "10.0", "9.0");
    }

    @Test
    public void testDeleteTask_success() throws Exception {
        controller.addTask("Req1", "John", "Mary", "1", "01-01-2025", "8.0", "9.0");
        controller.deleteTask("1");
        assertEquals(0, controller.getDataTasks().size());
    }

    @Test(expected = Exception.class)
    public void testDeleteTask_notFound() throws Exception {
        controller.deleteTask("999");
    }

    @Test(expected = Exception.class)
    public void testDeleteTask_invalidId() throws Exception {
        controller.deleteTask("abc");
    }

    @Test
    public void testGetDataTasks_returnsAll() throws Exception {
        controller.addTask("R1", "A", "B", "1", "01-01-2025", "8.0", "9.0");
        controller.addTask("R2", "C", "D", "2", "01-01-2025", "9.0", "10.0");
        List<Task> tasks = controller.getDataTasks();
        assertEquals(2, tasks.size());
    }
}
