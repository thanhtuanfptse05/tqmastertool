import binarysearch.BinarySearch;
import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;

/**
 * JUnit tests for BinarySearch class (J1.S.P0006).
 */
public class BinarySearchTest {

    private BinarySearch bs;

    @Before
    public void setUp() {
        bs = new BinarySearch(10);
    }

    @Test
    public void testBinarySearch_foundInMiddle() {
        bs.setArray(new int[]{1, 3, 5, 7, 9, 11, 13});
        bs.sort();
        int idx = bs.search(7);
        assertTrue("7 should be found", idx >= 0);
        assertEquals(7, bs.getArray()[idx]);
    }

    @Test
    public void testBinarySearch_foundFirst() {
        bs.setArray(new int[]{2, 4, 6, 8, 10});
        bs.sort();
        int idx = bs.search(2);
        assertTrue(idx >= 0);
        assertEquals(2, bs.getArray()[idx]);
    }

    @Test
    public void testBinarySearch_foundLast() {
        bs.setArray(new int[]{2, 4, 6, 8, 10});
        bs.sort();
        int idx = bs.search(10);
        assertTrue(idx >= 0);
        assertEquals(10, bs.getArray()[idx]);
    }

    @Test
    public void testBinarySearch_notFound() {
        bs.setArray(new int[]{1, 3, 5, 7});
        bs.sort();
        assertEquals(-1, bs.search(4));
    }

    @Test
    public void testBinarySearch_emptyArray() {
        bs.setArray(new int[]{});
        assertEquals(-1, bs.search(5));
    }

    @Test
    public void testBinarySearch_singleElement_found() {
        bs.setArray(new int[]{42});
        bs.sort();
        assertEquals(0, bs.search(42));
    }

    @Test
    public void testBinarySearch_singleElement_notFound() {
        bs.setArray(new int[]{42});
        bs.sort();
        assertEquals(-1, bs.search(99));
    }

    @Test
    public void testSort_ascending() {
        bs.setArray(new int[]{5, 3, 9, 1, 7});
        bs.sort();
        int[] arr = bs.getArray();
        for (int i = 0; i < arr.length - 1; i++) {
            assertTrue("Array should be sorted ascending", arr[i] <= arr[i + 1]);
        }
    }

    @Test
    public void testBinarySearchDirect_withCustomArray() {
        int[] arr = {1, 3, 5, 7, 9};
        int idx = bs.binarySearch(arr, 5, 0, arr.length - 1);
        assertEquals(2, idx);
    }

    @Test
    public void testBinarySearchDirect_notFound() {
        int[] arr = {1, 3, 5, 7, 9};
        assertEquals(-1, bs.binarySearch(arr, 4, 0, arr.length - 1));
    }
}
