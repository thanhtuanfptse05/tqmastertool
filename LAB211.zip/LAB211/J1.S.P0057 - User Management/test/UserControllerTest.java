import user.controller.UserController;
import user.model.Account;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * JUnit tests for UserController (J1.S.P0057).
 * Note: UserController loads/saves to user.dat file.
 * Tests use in-memory state only (no file interaction).
 */
public class UserControllerTest {

    private UserController controller;

    @Before
    public void setUp() {
        // Fresh controller – starts with whatever is in user.dat (likely empty in test env)
        controller = new UserController();
        // Clear existing accounts to ensure isolation
        controller.getAccounts().clear();
    }

    @Test
    public void testCheckUsernameExist_false_initially() {
        assertFalse(controller.checkUsernameExist("testuser"));
    }

    @Test
    public void testCheckUsernameExist_null() {
        assertFalse(controller.checkUsernameExist(null));
    }

    @Test
    public void testAddAccount_success() throws Exception {
        Account acc = new Account("newuser", "pass123");
        controller.getAccounts().add(acc); // direct add to avoid file write
        assertTrue(controller.checkUsernameExist("newuser"));
    }

    @Test
    public void testCheckUsernameExist_caseInsensitive() {
        controller.getAccounts().add(new Account("TestUser", "pass"));
        assertTrue(controller.checkUsernameExist("testuser"));
        assertTrue(controller.checkUsernameExist("TESTUSER"));
    }

    @Test
    public void testFind_success() throws Exception {
        controller.getAccounts().add(new Account("alice", "secret123"));
        Account result = controller.find(new Account("alice", "secret123"));
        assertNotNull(result);
        assertEquals("alice", result.getUsername());
    }

    @Test(expected = Exception.class)
    public void testFind_wrongPassword() throws Exception {
        controller.getAccounts().add(new Account("alice", "secret123"));
        controller.find(new Account("alice", "wrongpass"));
    }

    @Test(expected = Exception.class)
    public void testFind_userNotFound() throws Exception {
        controller.find(new Account("notexist", "any"));
    }

    @Test(expected = Exception.class)
    public void testFind_nullAccount() throws Exception {
        controller.find(null);
    }

    @Test
    public void testFind_caseInsensitiveUsername() throws Exception {
        controller.getAccounts().add(new Account("Bob", "pass123"));
        Account result = controller.find(new Account("bob", "pass123"));
        assertNotNull(result);
    }
}
