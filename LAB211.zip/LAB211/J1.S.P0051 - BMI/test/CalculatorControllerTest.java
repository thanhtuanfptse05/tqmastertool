import calculator.controller.CalculatorController;
import calculator.model.BMIStatus;
import calculator.model.Operator;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * JUnit tests for CalculatorController – BMI and arithmetic (J1.S.P0051).
 */
public class CalculatorControllerTest {

    private CalculatorController controller;
    private static final double DELTA = 0.001;

    @Before
    public void setUp() {
        controller = new CalculatorController();
    }

    // ---- Arithmetic ----
    @Test
    public void testAdd() {
        assertEquals(7.0, controller.calculate(3, Operator.ADD, 4), DELTA);
    }

    @Test
    public void testSubtract() {
        assertEquals(1.0, controller.calculate(5, Operator.SUBTRACT, 4), DELTA);
    }

    @Test
    public void testMultiply() {
        assertEquals(12.0, controller.calculate(3, Operator.MULTIPLY, 4), DELTA);
    }

    @Test
    public void testDivide() {
        assertEquals(2.5, controller.calculate(5, Operator.DIVIDE, 2), DELTA);
    }

    @Test(expected = ArithmeticException.class)
    public void testDivideByZero() {
        controller.calculate(5, Operator.DIVIDE, 0);
    }

    @Test
    public void testExponent() {
        assertEquals(8.0, controller.calculate(2, Operator.EXPONENT, 3), DELTA);
    }

    // ---- BMI Score ----
    @Test
    public void testBMIScore_normal() {
        // 70 kg, 170 cm -> BMI = 70/(1.7^2) = 24.22
        double score = controller.calculateBMIScore(70, 170);
        assertEquals(24.22, score, 0.01);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testBMIScore_zeroHeight() {
        controller.calculateBMIScore(70, 0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testBMIScore_zeroWeight() {
        controller.calculateBMIScore(0, 170);
    }

    // ---- BMI Status ----
    @Test
    public void testBMIStatus_underStandard() {
        // BMI < 19
        assertEquals(BMIStatus.UNDER_STANDARD, controller.calculateBMI(40, 165));
    }

    @Test
    public void testBMIStatus_standard() {
        // BMI in [19,25]: 70kg, 185cm -> 20.45
        assertEquals(BMIStatus.STANDARD, controller.calculateBMI(70, 185));
    }

    @Test
    public void testBMIStatus_overweight() {
        // BMI in (25,30]: 80kg, 170cm -> 27.68
        assertEquals(BMIStatus.OVERWEIGHT, controller.calculateBMI(80, 170));
    }

    @Test
    public void testBMIStatus_fat() {
        // BMI in (30,40]: 100kg, 170cm -> 34.6
        assertEquals(BMIStatus.FAT, controller.calculateBMI(100, 170));
    }

    @Test
    public void testBMIStatus_veryFat() {
        // BMI > 40: 130kg, 170cm -> 45.0
        assertEquals(BMIStatus.VERY_FAT, controller.calculateBMI(130, 170));
    }
}
