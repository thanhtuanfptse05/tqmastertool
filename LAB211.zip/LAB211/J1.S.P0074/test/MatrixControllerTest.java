import matrix.controller.MatrixController;
import matrix.model.Matrix;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * JUnit tests for MatrixController (J1.S.P0074).
 */
public class MatrixControllerTest {

    private MatrixController controller;

    @Before
    public void setUp() {
        controller = new MatrixController();
    }

    @Test
    public void testAddition_2x2() {
        int[][] a = {{1, 2}, {3, 4}};
        int[][] b = {{5, 6}, {7, 8}};
        int[][] result = controller.additionMatrix(a, b);
        assertArrayEquals(new int[]{6, 8},  result[0]);
        assertArrayEquals(new int[]{10, 12}, result[1]);
    }

    @Test
    public void testSubtraction_2x2() {
        int[][] a = {{5, 6}, {7, 8}};
        int[][] b = {{1, 2}, {3, 4}};
        int[][] result = controller.subtractionMatrix(a, b);
        assertArrayEquals(new int[]{4, 4}, result[0]);
        assertArrayEquals(new int[]{4, 4}, result[1]);
    }

    @Test
    public void testMultiplication_2x2() {
        int[][] a = {{1, 2}, {3, 4}};
        int[][] b = {{5, 6}, {7, 8}};
        int[][] result = controller.multiplicationMatrix(a, b);
        // [1*5+2*7, 1*6+2*8] = [19, 22]
        // [3*5+4*7, 3*6+4*8] = [43, 50]
        assertArrayEquals(new int[]{19, 22}, result[0]);
        assertArrayEquals(new int[]{43, 50}, result[1]);
    }

    @Test
    public void testMultiplication_nonSquare() {
        int[][] a = {{1, 2, 3}, {4, 5, 6}};  // 2x3
        int[][] b = {{7, 8}, {9, 10}, {11, 12}}; // 3x2
        int[][] result = controller.multiplicationMatrix(a, b);
        // Result should be 2x2
        assertEquals(2, result.length);
        assertEquals(2, result[0].length);
        // row0: [1*7+2*9+3*11, 1*8+2*10+3*12] = [58, 64]
        assertArrayEquals(new int[]{58, 64}, result[0]);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddition_dimensionMismatch() {
        int[][] a = {{1, 2}};
        int[][] b = {{1, 2}, {3, 4}};
        controller.additionMatrix(a, b);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMultiplication_dimensionMismatch() {
        int[][] a = {{1, 2}, {3, 4}}; // 2x2
        int[][] b = {{1, 2, 3}};       // 1x3 – cols of a != rows of b
        controller.multiplicationMatrix(a, b);
    }

    @Test
    public void testAdd_MatrixWrapper() {
        Matrix m1 = new Matrix(new int[][]{{1, 0}, {0, 1}});
        Matrix m2 = new Matrix(new int[][]{{2, 3}, {4, 5}});
        Matrix result = controller.add(m1, m2);
        assertEquals(3, result.get(0, 0));
        assertEquals(3, result.get(0, 1));
    }

    @Test
    public void testSubtract_MatrixWrapper() {
        Matrix m1 = new Matrix(new int[][]{{5, 6}, {7, 8}});
        Matrix m2 = new Matrix(new int[][]{{1, 2}, {3, 4}});
        Matrix result = controller.subtract(m1, m2);
        assertEquals(4, result.get(0, 0));
    }

    @Test
    public void testMultiply_MatrixWrapper() {
        Matrix m1 = new Matrix(new int[][]{{1, 2}, {3, 4}});
        Matrix m2 = new Matrix(new int[][]{{1, 0}, {0, 1}});
        Matrix result = controller.multiply(m1, m2);
        // Identity matrix multiplication
        assertEquals(1, result.get(0, 0));
        assertEquals(2, result.get(0, 1));
    }
}
