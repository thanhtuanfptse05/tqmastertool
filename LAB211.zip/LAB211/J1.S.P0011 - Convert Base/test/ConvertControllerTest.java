import convertbase.controller.ConvertController;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * JUnit tests for ConvertController (J1.S.P0011).
 */
public class ConvertControllerTest {

    private ConvertController controller;

    @Before
    public void setUp() {
        controller = new ConvertController();
    }

    // Decimal -> Binary
    @Test
    public void testDecimalToBinary_10() {
        assertEquals("1010", controller.convert("10", 10, 2));
    }

    @Test
    public void testDecimalToBinary_0() {
        assertEquals("0", controller.convert("0", 10, 2));
    }

    @Test
    public void testDecimalToBinary_255() {
        assertEquals("11111111", controller.convert("255", 10, 2));
    }

    // Binary -> Decimal
    @Test
    public void testBinaryToDecimal_1010() {
        assertEquals("10", controller.convert("1010", 2, 10));
    }

    @Test
    public void testBinaryToDecimal_11111111() {
        assertEquals("255", controller.convert("11111111", 2, 10));
    }

    // Decimal -> Hex
    @Test
    public void testDecimalToHex_255() {
        assertEquals("FF", controller.convert("255", 10, 16));
    }

    @Test
    public void testDecimalToHex_16() {
        assertEquals("10", controller.convert("16", 10, 16));
    }

    // Hex -> Decimal
    @Test
    public void testHexToDecimal_FF() {
        assertEquals("255", controller.convert("FF", 16, 10));
    }

    @Test
    public void testHexToDecimal_lowercase() {
        // BigInteger accepts lowercase hex
        assertEquals("255", controller.convert("ff", 16, 10));
    }

    // Binary -> Hex
    @Test
    public void testBinaryToHex() {
        assertEquals("FF", controller.convert("11111111", 2, 16));
    }

    // Hex -> Binary
    @Test
    public void testHexToBinary() {
        assertEquals("11111111", controller.convert("FF", 16, 2));
    }

    // Same base
    @Test
    public void testSameBase_returnsSameUpperCase() {
        assertEquals("ABC", controller.convert("abc", 16, 16));
    }

    // Exception on empty
    @Test(expected = IllegalArgumentException.class)
    public void testEmptyValue_throwsException() {
        controller.convert("", 10, 2);
    }
}
