import shape.controller.ShapeController;
import shape.model.Circle;
import shape.model.Rectangle;
import shape.model.Triangle;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * JUnit tests for ShapeController (J1.S.P0061).
 */
public class ShapeControllerTest {

    private ShapeController controller;
    private static final double DELTA = 0.001;

    @Before
    public void setUp() {
        controller = new ShapeController();
    }

    // ---- Triangle validation ----
    @Test
    public void testIsValidTriangle_valid() {
        assertTrue(controller.isValidTriangle(3, 4, 5));
    }

    @Test
    public void testIsValidTriangle_equilateral() {
        assertTrue(controller.isValidTriangle(5, 5, 5));
    }

    @Test
    public void testIsValidTriangle_degenerate() {
        assertFalse(controller.isValidTriangle(1, 2, 3)); // 1+2=3 fails strict >
    }

    @Test
    public void testIsValidTriangle_negativesSide() {
        assertFalse(controller.isValidTriangle(-1, 4, 5));
    }

    @Test
    public void testIsValidTriangle_zeroSide() {
        assertFalse(controller.isValidTriangle(0, 4, 5));
    }

    // ---- Rectangle ----
    @Test
    public void testCreateRectangle_valid() {
        Rectangle r = controller.createRectangle(4, 5);
        assertNotNull(r);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateRectangle_zeroWidth() {
        controller.createRectangle(0, 5);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateRectangle_negativeLength() {
        controller.createRectangle(4, -1);
    }

    // ---- Circle ----
    @Test
    public void testCreateCircle_valid() {
        Circle c = controller.createCircle(5);
        assertNotNull(c);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateCircle_zeroRadius() {
        controller.createCircle(0);
    }

    // ---- Triangle creation ----
    @Test
    public void testCreateTriangle_valid() {
        Triangle t = controller.createTriangle(3, 4, 5);
        assertNotNull(t);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateTriangle_invalid() {
        controller.createTriangle(1, 2, 10);
    }
}
