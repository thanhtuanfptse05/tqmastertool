import fruit.controller.FruitController;
import fruit.model.Fruit;
import fruit.model.OrderItem;
import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;
import static org.junit.Assert.*;

/**
 * JUnit tests for FruitController (J1.L.P0023).
 */
public class FruitControllerTest {

    private FruitController controller;

    @Before
    public void setUp() {
        controller = new FruitController();
    }

    @Test
    public void testAddFruit_newFruit() {
        controller.addFruit(new Fruit(1, "Apple", 10000, 50, "Vietnam"));
        assertEquals(1, controller.getFruitList().size());
    }

    @Test
    public void testAddFruit_duplicateId_updatesQuantityAndPrice() {
        controller.addFruit(new Fruit(1, "Apple", 10000, 50, "Vietnam"));
        controller.addFruit(new Fruit(1, "Apple", 12000, 20, "Vietnam"));
        assertEquals(1, controller.getFruitList().size());
        Fruit f = controller.getFruitById(1);
        assertEquals(70, f.getQuantity());
        assertEquals(12000.0, f.getPrice(), 0.001);
    }

    @Test
    public void testGetFruitById_found() {
        controller.addFruit(new Fruit(2, "Banana", 5000, 30, "Thailand"));
        assertNotNull(controller.getFruitById(2));
    }

    @Test
    public void testGetFruitById_notFound() {
        assertNull(controller.getFruitById(999));
    }

    @Test
    public void testGetAvailableFruits_excludesZeroQty() {
        controller.addFruit(new Fruit(1, "Apple", 10000, 10, "VN"));
        controller.addFruit(new Fruit(2, "Mango", 8000, 0, "TH")); // 0 qty
        ArrayList<Fruit> available = controller.getAvailableFruits();
        assertEquals(1, available.size());
        assertEquals(1, available.get(0).getFruitId());
    }

    @Test
    public void testDeductStock_success() {
        controller.addFruit(new Fruit(1, "Apple", 10000, 10, "VN"));
        assertTrue(controller.deductStock(1, 5));
        assertEquals(5, controller.getFruitById(1).getQuantity());
    }

    @Test
    public void testDeductStock_insufficientStock() {
        controller.addFruit(new Fruit(1, "Apple", 10000, 3, "VN"));
        assertFalse(controller.deductStock(1, 5));
        assertEquals(3, controller.getFruitById(1).getQuantity()); // unchanged
    }

    @Test
    public void testDeductStock_fruitNotFound() {
        assertFalse(controller.deductStock(999, 1));
    }

    @Test
    public void testAddOrder_newCustomer() {
        ArrayList<OrderItem> items = new ArrayList<OrderItem>();
        items.add(new OrderItem(1, "Apple", 2, 10000));
        controller.addOrder("Alice", items);
        assertTrue(controller.getOrdersTable().containsKey("Alice"));
        assertEquals(1, controller.getOrdersTable().get("Alice").size());
    }

    @Test
    public void testAddOrder_existingCustomer_appendsItems() {
        ArrayList<OrderItem> items1 = new ArrayList<OrderItem>();
        items1.add(new OrderItem(1, "Apple", 2, 10000));
        ArrayList<OrderItem> items2 = new ArrayList<OrderItem>();
        items2.add(new OrderItem(2, "Banana", 3, 5000));
        controller.addOrder("Bob", items1);
        controller.addOrder("Bob", items2);
        assertEquals(2, controller.getOrdersTable().get("Bob").size());
    }
}
